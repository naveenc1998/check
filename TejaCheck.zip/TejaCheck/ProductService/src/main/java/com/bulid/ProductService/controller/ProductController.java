package com.bulid.ProductService.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/products")
public class ProductController {
	
	
	@GetMapping
	public String getProducts() {
		return "HTTP GET Handled";
	}

	@PostMapping
	public String saveProducts() {
		return "HTTP POST Handled";
	}
	
	@PutMapping
	public String updateProducts() {
		return "HTTP PUT Handled";
	}
	
	@DeleteMapping
	public String deleteProducts() {
		return "HTTP DELETE Handled";
	}
}
